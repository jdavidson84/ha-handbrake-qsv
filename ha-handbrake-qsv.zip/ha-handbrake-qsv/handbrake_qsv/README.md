# HandBrake QSV Add-on

This Home Assistant add-on provides a headless HandBrake encoder with Intel QSV support.

## Configuration Options
- `input`: Folder to watch
- `output`: Encoded output folder
- `preset`: HandBrake preset
- `extra_args`: Extra CLI parameters
